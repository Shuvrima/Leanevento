<div id="menubar">			
	<img src="<?php echo base_url( 'images/logo-blanco.png');?>" alt="logo" style=" width: 40px;height:40px; position: realtive; margin-right:330px">
	<p style="position:absolute; margin-left:170px; margin-top:-30px ;font-weight:bolder">LEANEVENTOS</p>
	<a href="<?php echo base_url(); ?>home"  name="Inicio"style="text-decoration : none;padding-left:20px" > Inicio </a>
	<a href="<?php echo base_url(); ?>15agtind"  name="Lista de Voluntarios"style="text-decoration : none;padding-left:20px"> Lista de Voluntarios </a>
	<a href="<?php echo base_url(); ?>16agtbusi"  name="Lista de Fundaciones" style="text-decoration : none;padding-left:20px"> Lista de Fundaciones </a>
	<a href="<?php echo base_url(); ?>17eventagt"  name="Eventos"style="text-decoration : none;padding-left:20px"> Eventos </a>
	<a href="<?php echo site_url('Cont_19perfilag/ag_fetch'); ?>"  name="Agente"style="text-decoration : none;padding-left:20px" > Agente </a>
</div>
			
			
<div style="position:absolute;z-index:-1">
	<img src="<?php echo base_url( 'images/minibaner1.jpg');?>" alt="lean banner"style="width: 150%; height:400px" >
</div>
<div style="position:absolute;z-index:+1; margin-left:850px">
	<img src="<?php echo base_url( 'images/logo-blanco.png');?>" alt="lean banner" style=" width: 60%; height:50%">
</div>

<footer>
<div id="footer2">
	<h6 style="margin-top: 500px">Copyright @2019 All rights reserved | This web is made with <i class="far fa-heart"></i> by <a href name="DiazApps" style="text-decoration : none; color:orange" > DiazApps </a></h6>
</div>
</footer>
   
</body>
</html>