<div id="menubar">
	<img src="<?php echo base_url( 'images/logo-blanco.png');?>" alt="logo" style=" width: 40px;height:40px; position: realtive; margin-right:220px">
	<p style="position:absolute; margin-left:170px; margin-top:-30px ;font-weight:bolder">LEANEVENTOS</p>
		<a href="<?php echo base_url(); ?>home"  name="Inicio"style="text-decoration : none;padding-left:20px" > Inicio </a>
		<a href="<?php echo base_url(); ?>about"  name="Quienes Somos"style="text-decoration : none;padding-left:20px"> Quienes Somos </a>
		<a href=" http://asmitaorpe.uta.cloud"  name="Blog" style="text-decoration : none;padding-left:20px" > Blog </a>
		<a href="<?php echo site_url('Cont_7I/ind_reg'); ?>"  name="Registrate"style="text-decoration : none;padding-left:20px"> Registrate </a>
		<a href="<?php echo site_url('Cont_5msg/contact'); ?>"  name="Contacto"style="text-decoration : none;padding-left:20px" > Contacto </a>
		<a href="<?php echo site_url('Cont_login/login'); ?>"  name="Iniciar Sesion"style="text-decoration : none;padding-left:20px" > Iniciar Sesion </a>
		<a href="<?php echo base_url(); ?>3neweve"  name="Comprar Boletos" style="text-decoration : none;padding-left:20px" >Comprar Boletos</a>
</div>


<div id="imagemov3"></div>		
		
		
<div id="fonts5">
	<h3>  NUESTROS EVENTOS  </h3>
	<p>
	   Tu asistencia es importante para nosotros visitanos en los eventos qu estamos realizando.
	</p>
</div>
		
		
<table>	  
    <tr>
		<td>
			<div style="margin-left:70px; padding-bottom: 120px">
			<img src="<?php echo base_url( 'images/minibaner4.jpg');?>" alt="minibaner4" style="width:250px; height:300px">
			<figcaption> NO PERDAMOS LA FE <br> <font color="orange">$300.00</font></figcaption>
			</div>
		</td>
		<td>
			<div style=" padding-left:30px; padding-bottom: 120px">
			<img src="<?php echo base_url( 'images/minibaner1.jpg');?>" alt="minibaner1" style="width:250px; height:300px">	
			<figcaption> LA IMPORTANCIA DELOS ALIMENTOS<br> <font color="orange">$300.00</font></figcaption>
			</div>
		</td>
		<td>
			<div style=" padding-left:30px; padding-bottom: 120px">
			<img src="<?php echo base_url( 'images/minibaner2.jpg');?>" alt="minibaner2" style="width:250px; height:300px">
			<figcaption> EDUCANDO PARA EL FUTURO<br> <font color="orange">Entrade Gratis</font></figcaption>			
			</div>
		</td>
		<td>
			<div style=" padding-left:30px; padding-bottom: 120px">
			<img src="<?php echo base_url( 'images/minibaner3.jpg');?>" alt="minibaner3" style="width:250px; height:300px">
			<figcaption>OR UNA SONRISA DE VIDA<br> <font color="orange">$300.00</font></figcaption>	
			</div>
		</td>
	</tr>
</table>

	
		
		
<div id="orange1">
	
	<i class="far fa-paper-plane"></i>
	Regístrese para recibir un <br>
    <center> boletín </center>
</div>