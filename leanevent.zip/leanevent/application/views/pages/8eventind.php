

<div id="menubar">	
	<img src="<?php echo base_url('images/logo-blanco.png');?>" alt="logo" style=" width: 40px;height:40px; position: realtive; margin-right:700px">
	<p style="position:absolute; margin-left:170px; margin-top:-30px ;font-weight:bolder">LEANEVENTOS</p>
	<a href="<?php echo base_url(); ?>home"  name="Inicio"style="text-decoration : none;padding-left:20px" > Inicio </a>
	<a href="<?php echo site_url('Cont_9perfil/ind_fetch'); ?>"  name="Individual" style="text-decoration : none; padding-left:20px"> Individual </a>
</div>
			
			
<div class="container_event">		
	<h2 style="padding-top: 40px"> <center> Lista De Eventos </center> </h2>

	<table>
	  
	  <tr>
	  <div >
		<th style="background-color:lightgrey;padding-bottom:8px;padding-top:8px"><center>DETALLES DE EVENTOS</center></th>
		<th style="background-color:lightgrey;padding-bottom:8px;padding-top:8px"><center>LUGAR</center></th>
		<th style="background-color:lightgrey;padding-bottom:8px;padding-top:8px"><center>FECHA</center></th>
		<th style="background-color:lightgrey;padding-bottom:8px;padding-top:8px"><center>HORA</center></th>
		<th style="background-color:lightgrey;padding-bottom:8px;padding-top:8px"><center>ASISTANCIA</center></th>
	  </div>
	  </tr>
	  
	  
	  <tr>
		<td id="td1"><img src="<?php echo base_url('images/bannerlean1.jpg');?>" alt="lean banner" style=" width: 10%; height:10%; padding-right: 40px">Nombre del evento y sus detalles</td>
		<td id="td1"></td>
		<td id="td1">14/01/2019</td>
		<td id="td1">8 AM</td>
		<td id="td1"><button class="button6" >Confirmar</button></td>
	  </tr>
	  <tr>
		<td id="td1"><img src="<?php echo base_url('images/bannerlean2.jpg');?>" alt="lean banner" style=" width: 10%; height:10%; padding-right: 40px">Nombre del evento y sus detalles</td>
		<td id="td1">direccion del lugar</td>
		<td id="td1">14/01/2019</td>
		<td id="td1">8 AM</td>
		<td id="td1"><button class="button6" >Confirmar</button></td>
	  </tr>
	  <tr>
		<td id="td1"><img src="<?php echo base_url('images/bannerlean3.jpg');?>" alt="lean banner" style=" width: 10%; height:10%; padding-right: 40px">Nombre del evento y sus detalles</td>
		<td id="td1">direccion del lugar</td>
		<td id="td1">14/01/2019</td>
		<td id="td1">8 AM</td>
		<td id="td1"><button class="button6" >Confirmar</button></td>
	  </tr>
	</table>
</div>