<div id="logo2"></div>
<div id="lean2">
	<p id="lean2">LEANEVENTOS</p>
</div>



<div id="menubar">
	<a href="<?php echo base_url(); ?>home"  name="Inicio"style="text-decoration : none;padding-left:20px" > Inicio </a>
	<a href="<?php echo base_url(); ?>about"  name="Quienes Somos"style="text-decoration : none;padding-left:20px"> Quienes Somos </a>
	<a href="http://asmitaorpe.uta.cloud"  name="Blog" style="text-decoration : none;padding-left:20px" > Blog </a>
	<a href="<?php echo site_url('Cont_7I/ind_reg'); ?>"  name="Registrate"style="text-decoration : none;padding-left:20px"> Registrate </a>
	<a href="<?php echo site_url('Cont_5msg/contact'); ?>"  name="Contacto"style="text-decoration : none;padding-left:20px" > Contacto </a>
	<a href="<?php echo site_url('Cont_login/login'); ?>"  name="Iniciar Sesion"style="text-decoration : none;padding-left:20px" > Iniciar Sesion </a>
	<a href="<?php echo base_url(); ?>3neweve"  name="Comprar Boletos" style="text-decoration : none;padding-left:20px" > Comprar Boletos </a>
</div>


<div id="imagemov2"></div>	


<div class="row1">
	  <div class="column" style="padding-left:0px" >
	    <p>
			<h3> Què es LEAN?</h3>
			LEAN es una asocian civil sin fines de lucro conformada por gente con gran sensibilidad
			social, deddicada a la defensa de los derechos humanos y la consecucion de ayuda
			humanitaria, favoreciendo directamente o a traves de otras asociaciones o argupaciones
			provinciales a venezolanos residentes en Espana y a quienes viven en Venezuela.
		</p>
		<p>
			<h3> Cuáles son los fines de LEAN? </h3>
			LEAN esta dedicada a fomentar valores e instaurarlos como principios, trabajar en formacion
			civica, promover y defender las libertadesindividuales y los derechos humanos en Venezuela,
			sensibilizar a la gente sobre la importancia de conocer, respetar y practicar los principios
			contenidos en la Decleracion Universal de Derechos Humanos, asistir a victimas de actos
			violentos y persecucion, favorecer la adquisicion de conocimiento a traves de la lectura y
			teabajar incansablemente en la ayuda humanitaria como gesto de solidaridad y buena
			voluntad
		</p>
		<p>
			<h3> Cuáles son las  actividades de LEAN? </h3>
			LEAN trabaja en el desarrollo y  publicacion de estudios de investigacion sobre temas de
			interes social, cultural, politico y economico, preparacionde ponencias para foros y
			conferencias, presentacion en eventos especializados y mesas de trabajo, peticion de
			colaboracion a personalidades de reconocida tryectoria, estudio de casos  de violacion de
			derechos humanos a traves de letrados voluntarios, asistancia y representacion para la
			defensa de la victimas de actos violentos y persecucion, lanzamiento de campanas sobre
			valores civicos y derechos humanos, planificacion, y ejecucion de programas de voluntariado
			para brindar ayuda humanitaria y organizacion de charlas sobre la situacion economica
			politica y social de Venezuela y demas temas de interes mundial
		</p>
		<p>
			<h3> Qu Hacemos? </h3>
			La asociacion civil LEAN fu creada con el objetivo de ayudar, a traves de acciones concretas,
			a nuestros conciudadanos en Venezuela ante la grave escasez de medicinas e insumos
			medicos en que se encuentra el pais. Nuestra mision consiste en recolectar ayuda medico
			sanitaria en delegaciones en Espana y, a traves de agentes de transporte, llevarios a
			Venezuela para que otras asociaciones se encarguen de su distribucion. De esta manera
			aportamos nuestro granito de arena ayudando a llevar asistencia humanitaria a Venezuela.
			Somos una asociacion sins fines de lucro, dedicada a la defensa de los Derechos Humanos.
		</p>
	  </div>
	  
	  
	  
	  <div class="column1" >
		<p>
			<h3> Como puedes ayudar? </h3>
			<h4> Puedes ayudar de tres formas: </h4>
			<li> Dona material medico e insumos para Venezuela</li>
			<li> A traves de donaciones economicas</li>
			<li> Hazte voluntario</li>
		</p>
		<p>
			<h3> Cuáles son los fines de LEAN? </h3>
			LEAN esta dedicada a fomentar valores e instaurarlos como principios, trabajar en formacion
			civica, promover y defender las libertadesindividuales y los derechos humanos en Venezuela,
			sensibilizar a la gente sobre la importancia de conocer, respetar y practicar los principios
			contenidos en la Decleracion Universal de Derechos Humanos, asistir a victimas de actos
			violentos y persecucion, favorecer la adquisicion de conocimiento a traves de la lectura y
			teabajar incansablemente en la ayuda humanitaria como gesto de solidaridad y buena
			voluntad
		</p>
		<p>
			<h3> Donde estemos? </h3>
			<h4> Somos 17 Coordinacines en Espana: </h4>
			Alicante - Almeria - Cataluna - Granada - Islas Canarias - Islas Beleares - Leon<br>
			- Madrid - Malaga - Salamanca - Sevilla - Valencia - valladolid - Zaragoza -<br>
			LEAN EEUU
			<h4> Instituciones y Organizaciones Beneficiadas en Venezuela: </h4> 
			<h5> Ayudamos a 11 Estados a traves de 35 puntos de destino: </h5>
			<div class="row1">
				<div class="column2" style="margin-top:-40px" >
					<p>
						<li> LEAN Anzoategui</li>
						<li> Funsaluz Barcelona,<br> Valencia MAracaibo</li>
						<li>Fundacion la Pastillita</li>
						<li>LEAN Aragua 1</li>
						<li>Parroquia Michelena</li>
						<li>LEAN caracas 1,2,3,4,5,<br>6,7,8 y 9.</li>
						<li>Seno Salud</li>
						<li>Somos Ayuda</li>
						<li>FDIV</li>
						<li>Parroq.San Fco.de Asis</li>
						<li>ONG Pan y Vino</li>
						<li>LEAN nueva Esparta</li>
						<li>Parroqui San Felix</li>
						<li>Fundacion Esparanza de<br>Vida</li>
						<li>Caritas de Venezuela</li>
					</p>
				</div>
				<div class="column3" style=" margin-top:-30px" >
					<p>
						<li> Fund.Denzel El Guerrero</li>
						<li> Mensajeras de la Alegria</li>
						<li>Caritas Valle de la Pascua</li>
						<li>Caritas Diocesana<br> Barquisimeto</li>
						<li>Hogar de Ninos Impedidos <br> don Orione</li>
						<li>AVEPEII</li>
						<li>Casa Hogar Madre Teresa <br>de Calcuta</li>
						<li>Seminario Santa Rosa de <br>lima</li>
						<li>Casa Aragon</li>
						<li>Caritas Parroquial de Merida</li>
						<li>Asociacion Dr.Paul<br>Moreno Camacho</li>
						<li>FUNDAYUDANOS</li>
					</p>
				</div>
			</div>
		</p>
	 </div>
</div>



<div id="orange1">
	<i class="far fa-paper-plane"></i>
	Regístrese para recibir un <br>
	<center> boletín </center>
</div>


