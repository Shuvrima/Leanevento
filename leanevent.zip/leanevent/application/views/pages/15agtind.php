<div id="menubar">		
	<img src="<?php echo base_url('images/logo-blanco.png');?>" alt="logo" style=" width: 40px;height:40px; position: realtive; margin-right:330px">
	<p style="position:absolute; margin-left:170px; margin-top:-30px ;font-weight:bolder">LEANEVENTOS</p>
	<a href="<?php echo base_url(); ?>14homeagent"  name="Inicio"style="text-decoration : none;padding-left:20px" > Inicio </a>
	<a href="<?php echo base_url(); ?>15agtind"  name="Lista de Voluntarios"style="text-decoration : none;padding-left:20px"> Lista de Voluntarios </a>
	<a href="<?php echo base_url(); ?>16agtbusi"  name="Lista de Fundaciones" style="text-decoration : none;padding-left:20px"> Lista de Fundaciones </a>
	<a href="<?php echo base_url(); ?>17eventagt"  name="Eventos"style="text-decoration : none;padding-left:20px"> Eventos </a>
	<a href="<?php echo site_url('Cont_19perfilag/ag_fetch'); ?>"  name="Agente"style="text-decoration : none;padding-left:20px" > Agente </a>
</div>
			
			
<div class="container_event">		
<h2 style="padding-top: 40px"> <center> Lista De Voluntarios </center> </h2>
	
	
<table>
	<tr>
	  <div >
	    <th style="background-color:lightgrey;padding-bottom:8px;padding-top:8px"><center>NOMBRE DE VOLUNTARIO</center></th>
		<th style="background-color:lightgrey;padding-bottom:8px;padding-top:8px"><center>CORREO</center></th>
		<th style="background-color:lightgrey;padding-bottom:8px;padding-top:8px"><center>TELEFONO</center></th>
		<th style="background-color:lightgrey;padding-bottom:8px;padding-top:8px"><center>EVENTO</center></th>
		<th style="background-color:lightgrey;padding-bottom:8px;padding-top:8px"><center>RESPONSABLE</center></th>	
	  </div>
	</tr>
	  
	  
	<tr>
		<td id="td1"><img src="<?php echo base_url('images/user.png');?>" alt="lean banner" style=" width: 10%; height:10%; padding-right: 40px">Nombre de voluntario</td>
		<td id="td1">Direccion</td>
		<td id="td1">0000-000000</td>
		<td id="td1">Nombre del evento</td>
		<td id="td1">Nombre del<br>Responsable</td>
	</tr>
	<tr>
		<td id="td1"><img src="<?php echo base_url('images/user.png');?>" alt="lean banner" style=" width: 10%; height:10%; padding-right: 40px">Nombre de voluntario</td>
		<td id="td1">Direccion</td>
		<td id="td1">0000-000000</td>
		<td id="td1">Nombre del evento</td>
		<td id="td1">Nombre del<br>Responsable</td>
	</tr>
	<tr>
		<td id="td1"><img src="<?php echo base_url('images/user.png');?>" alt="lean banner" style=" width: 10%; height:10%; padding-right: 40px">Nombre de voluntario</td>
		<td id="td1">Direccion</td>
		<td id="td1">0000-000000</td>
		<td id="td1">Nombre del evento</button></td>
		<td id="td1">Nombre del<br>Responsable</td>
	</tr>
</table>
</div>


