
<div id="menubar">
	<img src="logo-blanco.png" alt="logo" style=" width: 40px;height:40px; position: realtive; margin-right:220px">
	<p style="position:absolute; margin-left:170px; margin-top:-30px ;font-weight:bolder">LEANEVENTOS</p>
	<a href="<?php echo base_url(); ?>home"  name="Inicio"style="text-decoration : none;padding-left:20px" > Inicio </a>
	<a href="<?php echo base_url(); ?>about"  name="Quienes Somos"style="text-decoration : none;padding-left:20px"> Quienes Somos </a>
	<a href="<?php echo base_url(); ?> http://asmitaorpe.uta.cloud"  name="Blog" style="text-decoration : none;padding-left:20px" > Blog </a>
	<a href="7signup.html"  name="Registrate"style="text-decoration : none;padding-left:20px"> Registrate </a>
	<a href="<?php echo base_url(); ?>5msg"  name="Contacto"style="text-decoration : none;padding-left:20px" > Contacto </a>
	<a href="<?php echo base_url(); ?>6login"  name="Iniciar Sesion"style="text-decoration : none;padding-left:20px" > Iniciar Sesion </a>
	<a href="<?php echo base_url(); ?>3neweve"  name="Comprar Boletos" style="text-decoration : none;padding-left:20px" > Comprar Boletos </a>
</div>
			
<div id="imagemov4"></div>		


<table>	  
	<tr>
		<td>
			<div style="padding-top: 120px; padding-bottom:120px; margin-left:100px">
			<img src="<?php echo base_url( 'images/minibaner4.jpg');?>" alt="minibaner4" style="width:380px; height:380px">
			</div>
		</td>
		
		<td>
			<h5 id="fonts1">
			NO PERDAMOS LA FE<br>
			<br>
			$300.00
			</h5>
			<div id="text1">		
			La fe no puede perder JAMAS! Es imprescindible para todo en nuestras vidas,<br>
			poco a poco las cosas irán mejorando. No cambiaran de la noche a la mañana,<br>
			pero van a cambiar y solo cambiarán si te lo propones. Si hoy tuvimos un mal dia,<br>
			nuestra meta será tener uno mejor mañana. Es básicamente hacer nuestra la frase<br>
			"Hoy no me darè por vencido", repitela todos los dias, hazla parte de tu filosofia de<br>
			vida.<br>	
			<br>
			Numero de Entradas
			</div>
			
			<div style="padding-left:40px">
			<button class="button" ><i class="far fa-shopping-cart"></i>Comprar</button>
			</div>
			
		</td>
	</tr>
</table>
	
	
<table>
	  <tr>
		<td>
			<div style="margin-left:100px; padding-bottom:8px" >
			<button class="button1" >DESCRIPCION</button>
			</div>
		</td>
		<td>
			<div style="padding-bottom:8px" >
	        <button class="button1" >ENCARGADOS</button>
			</div>
		</td>
		<td>
			<div style="padding-bottom:8px" >
			<button class="button1" >PATROCINANTES</button>
			</div>
		</td>
	  </tr>
</table>	

	
<div id="texta4">	
	<textarea rows="12" cols="130">
		Recièn he comenzado a leer un libro cuyo mensaje principal es aprender abuscar ese algo mejor todos los dias. 
		El libro está escrito por una	persona que vive con diabetes tipo 1 y nos presenta como los adelantos en tratamientos y tecnologia, 
		aunque no han curado su condición, diatras dia mejoran su calidad de vida.
		Busquemos siempre mejorar algo en nuestra vidas, mantengamos el deseo de progresar, 
		de educamos más acerca de la condición de nuestroshijos y verás como poco a poco comenzaremos a entenderia mejor.	
	</textarea>
</div>

	
	
<div id="orange1">
	<i class="far fa-paper-plane"></i>
	Regístrese para recibir un <br>
    <center> boletín </center>
</div>