

<div id="logo1"></div>

<div id="lean1">
	<p id="lean1">LEANEVENTOS</p>
</div>

<div id="menubar">
	<a href="<?php echo base_url(); ?>home"  name="Inicio"style="text-decoration : none;padding-left:20px" > Inicio </a>
	<a href="<?php echo base_url(); ?>about"  name="Quienes Somos"style="text-decoration : none;padding-left:20px"> Quienes Somos </a>
	<a href="http://asmitaorpe.uta.cloud"  name="Blog" style="text-decoration : none;padding-left:20px" > Blog </a>
	<a href="<?php echo site_url('Cont_7I/ind_reg'); ?>"  name="Registrate"style="text-decoration : none;padding-left:20px"> Registrate </a>
	<a href="<?php echo site_url('Cont_5msg/contact'); ?>"  name="Contacto"style="text-decoration : none;padding-left:20px" > Contacto </a>
	<a href="<?php echo site_url('Cont_login/login'); ?>"  name="Iniciar Sesion"style="text-decoration : none;padding-left:20px" > Iniciar Sesion </a>
	<a href="<?php echo base_url(); ?>3neweve"  name="Comprar Boletos" style="text-decoration : none;padding-left:20px" > Comprar Boletos </a>
</div>


<div id="image1"></div>
<div id="image2"></div>
		
<div id="fonts">
	<h3> QUÉ HACEMOS? </h3>
	 <p>
	  <center>
	   La asociacion civil LEAN fuc creada con el objectivo de ayudar, a traves de acciones concretas, a nuestros conciudadanos<br>
	   en Venezuela ante la grave escasez de medicinas e insumos medicos en que se encuentra el pais Nuestra mision consiste<br>
	   en recolector ayuda medico sanitaria en delegaciones en Espana y, a traves de agentes de transporte, llevarios a Venezuela<br>
	  </center>
	 </p>
	 <p>
	 <center>
	   para que otras asociaciones se encarguen de su distribucion. De esta manera aportamos nuestro granito de arena<br>
	   ayudando a llevar asistencia humanitaria a Venezuela. Somos una asociacion sin fines de lucro, dedicada a la defensa de<br>
	   <center>1os Derechos Humanos</center>
	 </center>
	 </p>
</div>

	 
<div id="orangeblock">
		<pre> 
	   478              60,000       45
					
   VOLUNTARIOS PERSONAS BENEFICIADAS  ALIADOS				   
		</pre>
</div>
	
	
<div id="imagemov1">
	"La injusticia, en cualquier parte, es una amenaza a la justicia en todas partes."<br>
	<font style="font-style:italic; float:right-side">Martin Luther King</font>
</div>
	
	
<div id="fonts5">
	<h3> <center> ALIADOS </center> </h3>
</div>

	
<div class="row">
	  <div class="c1" style="padding-left:0px" >
		<div id="imagehome"><img src="<?php echo base_url( 'images/logo1.png');?>" alt="logo1" ></div>
		<div id="imagehome"><img src="<?php echo base_url( 'images/logo5.png');?>" alt="logo5"></div>
	  </div>
	  <div class="c2" style="padding-left:10px" >
		<div id="imagehome"><img src="<?php echo base_url( 'images/logo2.png');?>" alt="logo1" ></div>
		<div id="imagehome"><img src="<?php echo base_url( 'images/logo6.png');?>" alt="logo5"></div>
	  </div>
	   <div class="c3" style="padding-left:10px" >
		<div id="imagehome"><img src="<?php echo base_url( 'images/logo3.png');?>" alt="logo1" ></div>
		<div id="imagehome"><img src="<?php echo base_url( 'images/logo7.png');?>" alt="logo5"></div>
	  </div>
	   <div class="c4" style="padding-left:10px" >
		<div id="imagehome"><img src="<?php echo base_url( 'images/logo4.png');?>" alt="logo1" ></div>
		<div id="imagehome"><img src="<?php echo base_url( 'images/logo8.png');?>" alt="logo5"></div>
	  </div>
</div>
	

	
	
<div id="orange1">

		<i class="far fa-paper-plane"></i>
		Regístrese para recibir un <br>
	    <center> boletín </center>
		<form method="post">
		<input type="text" name="email" placeholder="Enter your email" width="300px">
		<center><input type="submit" name="i" color="black" value="subscribe"></center>
		</form>
</div>
