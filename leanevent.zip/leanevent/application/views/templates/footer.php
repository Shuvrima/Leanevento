 <footer>
	<div id="footer1">
	<h5> LEAN EN LAS REDES SOCIALES </h5>
	</div>
	<article id="icons1">
	<i class="fab fa-twitter"></i>
	<i class="fab fa-facebook-f"></i>
	<i class="fab fa-instagram"></i>
	</article>
	<div id="footer2">
	<h6>Copyright @2019 All rights reserved | This web is made with <i class="far fa-heart"></i> by <a href name="DiazApps" style="text-decoration : none; color:orange" > DiazApps </a></h6>
	</div>
 </footer>


	</body>
</html>