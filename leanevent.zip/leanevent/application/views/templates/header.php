<html>
	<head>
		<title> LEANEVENTOS </title>
		<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/leanevent.css">
		<link rel="stylesheet" type="text/css" href="leanevent.css" media="screen and (max-width:600px)">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta charset="utf-8">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
	</head>
	<body id="wrapper">
