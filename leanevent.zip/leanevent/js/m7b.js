// 7 signup


function generr(loc,msg,color)
{
	document.getElementById(loc).innerHTML=msg;
	document.getElementById(loc).style.color=color;
}


function checkep()   //check email and passwrd
{
	
	var email = document.getElementById("i22").value;
	var pw = document.getElementById("i23").value;
	
	if(email.length!=0 && pw.length!=0)
	{
		if(email.match(/^[A-Za-z0-9\.\-_]*@[a-z]+\.[a-z]+$/) && pw.match(/^[A-Za-z0-9\.\-_!@#$%^&*]{8,15}$/))
	   {
		  generr("e15","Done","green");
		  return true;
	   }
	   generr("e15","invalid format","red");
	   
	}
	else
		generr("e15","either field is missing","red");
		
}


function checknames()    //check names
{
	
	var fname = document.getElementById("i24").value;
	var lname = document.getElementById("i25").value;
	
	if(fname.length!=0 && lname.length!=0)
	{
		if(fname.match(/^[A-Za-z]*$/) && lname.match(/^[A-Za-z]*$/))
	   {
		  generr("e16","Done","green");
		  return true;
	   }
	   generr("e16","invalid format","red");
		  
	}
	
	else
		generr("e16","either field is missing","red");
		
}

function checkadd()    
{
	
	var adds = document.getElementById("i26").value;
	if(adds.length!=0)
	{
		if(adds.match(/^[0-9\sA-Za-z,]*$/))
		{
			generr("e17","Done","green");
			return true;
		}
		generr("e17","invalid format","red");
		
	}
	
	else
		generr("e17","either field is missing","red");
		
}

function checkcity()    
{
	var city = document.getElementById("i27").value;
	if(city.length!=0)
	{
		if(city.match(/^[A-Za-z]*$/))
	   {
		generr("e18","Done","green");
		return true;
	   }
	   generr("e18","invalid format","red");
		
	}
	else
		generr("e18","field is missing","red");
		
}

function checkzip()    //check names
{
	var state = document.getElementById("i28").value;
	var zip = document.getElementById("i29").value;
	if(state.length!=0 && zip.length!=0)
	{
		if(state.match(/^[A-Za-z]*$/) && zip.match(/^\d{5}$/))
	  {
		generr("e19","Done","green");
		return true;
	  }
		generr("e19","invalid format","red");
	}
	else
		generr("e19","either field is missing","red");
}



function openreg()
{
	 document.getElementById("pop").style.display ="block";	
}

function cancel() 
{
     document.getElementById("pop").style.display ="none";
}
