//******5 msg********
function generr(loc,msg,color)
{
	document.getElementById(loc).innerHTML=msg;
	document.getElementById(loc).style.color=color;
}


function check5email()   //check email and passwrd
{
	var email = document.getElementById("i3").value;
		
	if(email.length!=0)
	{
		if(email.match(/^[A-Za-z0-9\.\-_]*@[a-z]*\.[a-z]+$/))   // if no match returns null hence if doesnt go anywhere until true is returned
	    {
			generr("e3","done","green");
		    
			return true;
	    }
		generr("e3","invalid format","red");
		
	}
	else
        generr("e3","field is missing","red");
}	


function check5fn() 
{
	
	var fname = document.getElementById("i1").value;
	
	if(fname.length!=0)
	{
		if(fname.match(/^[A-Za-z]*$/))
	    {
		    generr("e1","done","green");
			return true;
	    }
		generr("e1","invalid","red");
		
	}
	else
        generr("e1","field is missing","red");
}

function check5ln() 
{
	
	var lname = document.getElementById("i2").value;
	
	if(lname.length!=0)
	{
		if(lname.match(/^[A-Za-z]*$/))
	    {
			generr("e2","done","green");
			return false;
	    }
		generr("e2","invalid format","red");
		
	}
	else
        generr("e2","field is missing","red");
}

//*********7signup*********

//7 signup

/*function register()
{
	var email1 = document.getElementsByClassName("i8").value;
	var pw1 = document.getElementsByClassName("i9").value;
	if (email1.length!=0 && pw1.length!=0)
	
		checkep("i8","i9","e5");	
	else
		generr("e5","either field is missing","red");
	
	
	var fn1 = document.getElementsByClassName("i10").value;
	var ln1 = document.getElementsByClassName("i11").value;
	if (fn1.length!=0 && ln1.length!=0)
	
		checknames("i10","i11","e6");	
	else
		generr("e6","either field is missing","red");
	
	
	var add1 = document.getElementsByClassName("i12").value;
	if (add1.length!=0)
	
		checkadd("i12","e7");	
	else
		generr("e7","either field is missing","red");
	
	
	var city1 = document.getElementsByClassName("i13").value;
	if (city1.length!=0)
	
		checkcity("i13","e8");	
	else
		generr("e8","either field is missing","red");
	
	
	var state1 = document.getElementsByClassName("i14").value;
	var zip1 = document.getElementsByClassName("i15").value;
	if (state1.length!=0 && zip1.length!=0)
	
		checkzip("i14","i15","e9");	
	else
		generr("e9","either field is missing","red");
	
		
}
*/












