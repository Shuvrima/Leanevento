function generr(loc,msg,color)
{
	document.getElementById(loc).innerHTML=msg;
	document.getElementById(loc).style.color=color;
}

function checkn()   //check email and passwrd
{
	var fn = document.getElementById("i36").value;
	var ln = document.getElementById("i37").value;	
	if(fn.length!=0 && ln.length!=0)
	{
		if(fn.match(/^[A-Za-z]*$/) && ln.match(/^[A-Za-z]*$/))
	    {
		    generr("e23","done","green");
			return true;
	    }
		generr("e23","no","red");
		
	}
	else
        generr("e23","field is missing","red");
}	

function check9email()   //check email and passwrd
{
	var email = document.getElementById("i38").value;
		
	if(email.length!=0)
	{
		if(email.match(/^[A-Za-z0-9\.\-_]*@[a-z]*\.[a-z]{3,4}$/))
	    {
		    generr("e24","done","green");
			return true;
	    }
		generr("e24","no","red");
		
	}
	else
        generr("e24","field is missing","red");
}	

function checkall()   //check email and passwrd
{
	var phone = document.getElementById("i39").value;
	var uname = document.getElementById("i40").value;
	var pass = document.getElementById("i41").value;	
	
	if(phone.length!=0 && pass.length!=0 && uname.length!=0)
	{
		if(uname.match(/^[A-Za-z0-9\.\-_]*@[a-z]*\.[a-z]{3,4}$/) && pass.match(/^[A-Za-z0-9\.\-_!@#$%^&*]{8,15}$/) && phone.match(/^\d{3}[\-]\d{3}[\-]\d{4}$/))
	    {
		    generr("e25","done","green");
			return true;
	    }
		generr("e25","no","red");
		
	}
	else
        generr("e25","field is missing","red");
}	