// 7 signup


function generr(loc,msg,color)
{
	document.getElementById(loc).innerHTML=msg;
	document.getElementById(loc).style.color=color;
}


function checkep()   //check email and passwrd
{
	
	var email = document.getElementById("i4").value;
	var pw = document.getElementById("i5").value;
	
	if(email.length!=0 && pw.length!=0)
	{
		if(email.match(/^[A-Za-z0-9\.\-_]*@[a-z]+\.[a-z]+$/) && pw.match(/^[A-Za-z0-9\.\-_!@#$%^&*]{8,15}$/))
	   {
		  generr("e4","Done","green");
		  return true;
	   }
	   generr("e4","invalid format","red");
	   
	}
	else
		generr("e4","either field is missing","red");
		
}


function checknames()    //check names
{
	
	var fname = document.getElementById("i6").value;
	var lname = document.getElementById("i7").value;
	
	if(fname.length!=0 && lname.length!=0)
	{
		if(fname.match(/^[A-Za-z]*$/) && lname.match(/^[A-Za-z]*$/))
	   {
		  generr("e5","Done","green");
		  return true;
	   }
	   generr("e5","invalid format","red");
		  
	}
	
	else
		generr("e5","either field is missing","red");
		
}

function checkadd()    
{
	
	var adds = document.getElementById("i8").value;
	if(adds.length!=0)
	{
		if(adds.match(/^[0-9\sA-Za-z,]*$/))
		{
			generr("e6","Done","green");
			return true;
		}
		generr("e6","invalid format","red");
		
	}
	
	else
		generr("e6","either field is missing","red");
		
}

function checkcity()    
{
	var city = document.getElementById("i9").value;
	if(city.length!=0)
	{
		if(city.match(/^[A-Za-z]*$/))
	   {
		generr("e7","Done","green");
		return true;
	   }
	   generr("e7","invalid format","red");
		
	}
	else
		generr("e7","field is missing","red");
		
}

function checkzip()    //check names
{
	var state = document.getElementById("i10").value;
	var zip = document.getElementById("i11").value;
	if(state.length!=0 && zip.length!=0)
	{
		if(state.match(/^[A-Za-z]*$/) && zip.match(/^\d{5}$/))
	  {
		generr("e8","Done","green");
		return true;
	  }
		generr("e8","invalid format","red");
	}
	else
		generr("e8","either field is missing","red");
}



function openreg()
{
	 document.getElementById("pop").style.display ="block";	
}

function cancel() 
{
     document.getElementById("pop").style.display ="none";
}
