// 6 login

function generr(loc,msg,color)
{
	document.getElementById(loc).innerHTML=msg;
	document.getElementById(loc).style.color=color;
}

function check6email()   //check email and passwrd
{
	var email = document.getElementById("i12").value;

		
	if(email.length!=0)
	{
		
		if(email.match(/^[A-Za-z0-9\.\-_]*@[a-z]*\.[a-z]{3,4}$/))
	    {
		    generr("e9","done","green");
			return true;
	    }
		generr("e9","no","red");
		
	}
	else
        generr("e9","field is missing","red");
}	


function checkpw()   //check email and passwrd
{

	var pw = document.getElementById("i13").value;
		
	if(pw.length!=0)
	{
		
		if(pw.match(/^[A-Za-z0-9\.\-_]*@[a-z]*\.[a-z]+$/))
	    {
		    generr("e9","done","green");
			return true;
	    }
		generr("e9","no","red");
		
	}
	else
        generr("e9","field is missing","red");
}	



