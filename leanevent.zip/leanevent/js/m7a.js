// 7 signup


function generr(loc,msg,color)
{
	document.getElementById(loc).innerHTML=msg;
	document.getElementById(loc).style.color=color;
}


function checkep()   //check email and passwrd
{
	
	var email = document.getElementById("i14").value;
	var pw = document.getElementById("i15").value;
	
	if(email.length!=0 && pw.length!=0*/)
	{
		if(email.match(/^[A-Za-z0-9\.\-_]*@[a-z]+\.[a-z]+$/) && pw.match(/^[A-Za-z0-9\.\-_!@#$%^&*]{8,15}$/))
	   {
		  generr("e10","Done","green");
		  return true;
	   }
	   generr("e10","invalid format","red");
	   
	}
	else
		generr("e10","either field is missing","red");
		
}


function checknames()    //check names
{
	
	var fname = document.getElementById("i16").value;
	var lname = document.getElementById("i17").value;
	
	if(fname.length!=0 && lname.length!=0)
	{
		if(fname.match(/^[A-Za-z]*$/) && lname.match(/^[A-Za-z]*$/))
	   {
		  generr("e11","Done","green");
		  return true;
	   }
	   generr("e11","invalid format","red");
		  
	}
	
	else
		generr("e11","either field is missing","red");
		
}

function checkadd()    
{
	
	var adds = document.getElementById("i18").value;
	if(adds.length!=0)
	{
		if(adds.match(/^[0-9\sA-Za-z,]*$/))
		{
			generr("e12","Done","green");
			return true;
		}
		generr("e12","invalid format","red");
		
	}
	
	else
		generr("e12","either field is missing","red");
		
}

function checkcity()    
{
	var city = document.getElementById("i19").value;
	if(city.length!=0)
	{
		if(city.match(/^[A-Za-z]*$/))
	   {
		generr("e13","Done","green");
		return true;
	   }
	   generr("e13","invalid format","red");
		
	}
	else
		generr("e13","field is missing","red");
		
}

function checkzip()    //check names
{
	var state = document.getElementById("i20").value;
	var zip = document.getElementById("i21").value;
	if(state.length!=0 && zip.length!=0)
	{
		if(state.match(/^[A-Za-z]*$/) && zip.match(/^\d{5}$/))
	  {
		generr("e14","Done","green");
		return true;
	  }
		generr("e14","invalid format","red");
	}
	else
		generr("e14","either field is missing","red");
}



function openreg()
{
	 document.getElementById("pop").style.display ="block";	
}

function cancel() 
{
     document.getElementById("pop").style.display ="none";
}
