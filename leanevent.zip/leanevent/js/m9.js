function generr(loc,msg,color)
{
	document.getElementById(loc).innerHTML=msg;
	document.getElementById(loc).style.color=color;
}


function checkn()   //check email and passwrd
{
	var fn = document.getElementById("i34").value;
	var ln = document.getElementById("i35").value;	
	if(fn.length!=0 && ln.length!=0)
	{
		if(fn.match(/^[A-Za-z]*$/) && ln.match(/^[A-Za-z]*$/))
	    {
		    generr("e22","done","green");
			return true;
	    }
		generr("e22","no","red");
		
	}
	else
        generr("e22","field is missing","red");
}	

function check9email()   //check email and passwrd
{
	var email = document.getElementById("i30").value;
		
	if(email.length!=0)
	{
		if(email.match(/^[A-Za-z0-9\.\-_]*@[a-z]*\.[a-z]{3,4}$/))
	    {
		    generr("e20","done","green");
			return true;
	    }
		generr("e20","no","red");
		
	}
	else
        generr("e20","field is missing","red");
}	

function checkall()   //check email and passwrd
{
	var phone = document.getElementById("i31").value;
	var uname = document.getElementById("i32").value;
	var pass = document.getElementById("i33").value;	
	
	if(phone.length!=0 && pass.length!=0 && uname.length!=0)
	{
		if(uname.match(/^[A-Za-z0-9\.\-_]*@[a-z]*\.[a-z]{3,4}$/) && pass.match(/^[A-Za-z0-9\.\-_!@#$%^&*]{8,15}$/) && phone.match(/^\d{3}[\-]\d{3}[\-]\d{4}$/))
	    {
		    generr("e21","done","green");
			return true;
	    }
		generr("e21","no","red");
		
	}
	else
        generr("e21","field is missing","red");
}	