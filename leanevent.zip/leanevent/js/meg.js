

/*function check5email()   //check email and passwrd
{
	
	var email = document.getElementById("g1").value;
		
	if(email.length==0)
	{
		generr("e3","field is missing","red");
	}
	if(!email.match(/^[A-Za-z0-9\.\-_]*@[a-z]+\.[a-z]+$/))
	{
	  generr("e3","invalid format","red");
	}
	else
		generr("e3","Done","green");
			
}
*/

/*function check5fn() 
{
	var fname = document.getElementById("g2").value;
	if(fname.length!=0)
	{
		if(fname.match(/^[A-Za-z]*$/))
	  {
		generr("e3","Done","green");
		return false;
	  }
		generr("e3","invalid format","red");
	}
	else
		generr("e3","field is missing","red");
		
}
*/
function generr(loc,msg,color)
{
	document.getElementById(loc).innerHTML=msg;
	document.getElementById(loc).style.color=color;
}

function check5email()   //check email and passwrd
{
	var email = document.getElementById("g1").value;
	var fname = document.getElementById("g2").value;	
	if(email.length!=0 && fname.length!=0)
	{
		if(email.match(/^[A-Za-z0-9\.\-_]*@[a-z]*\.[a-z]{3,4}$/) && fname.match(/^[A-Za-z]*$/))
	    {
		    generr("e3","done","green");
			return true;
	    }
		generr("e3","no","red");
		
	}
	else
        generr("e3","field is missing","red");
}	

	
	
	
	
	
	
	
	
	
	
	
	
	