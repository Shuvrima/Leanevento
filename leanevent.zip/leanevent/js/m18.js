function generr(loc,msg,color)
{
	document.getElementById(loc).innerHTML=msg;
	document.getElementById(loc).style.color=color;
}


function check1()   
{
	var n1 = document.getElementById("i48").value;
	var n2 = document.getElementById("i49").value;	
	if(n1.length!=0 && n2.length!=0)
	{
		if(n1.match(/^[A-Za-z]*$/) && n2.match(/^[A-Za-z]*$/))
	    {
		    generr("e29","done","green");
			return true;
	    }
		generr("e29","no","red");
		
	}
	else
        generr("e29","field is missing","red");
}	


function check2()   
{
	var place = document.getElementById("i50").value;
	var d = document.getElementById("i51").value;	
	var t = document.getElementById("i52").value;
	var cost = document.getElementById("i53").value;
	if(place.length!=0 && date.length!=0 && time.length!=0 && cost.length!=0)
	{
		if(place.match(/^[A-Za-z0-9]*$/) && d.match(/^\d{4}\/\d{2}\/\d{2}$/) && t.match(/^[0-24]{2}:[0-59]{2}$/) && cost.match(/^\d{1,3}\.\d{2}$/))
	    {
		    generr("e30","done","green");
			return true;
	    }
		generr("e30","no","red");
		
	}
	else
        generr("e30","field is missing","red");
}	
